<?php
// ================================================================
//  FAMAKO — CONFIG UNIFIÉE  (config/database.php)
//  Une seule base : `famako`
//  Utilisé par : site principal  ET  bibliothèque numérique
// ================================================================

// ── Identifiants base de données ────────────────────────────────
define('DB_HOST',    'localhost');
define('DB_NAME',    'famako_db');          // ← base unique
define('DB_USER',    'root');            // WAMP/XAMPP : root
define('DB_PASS',    '');               // mot de passe vide par défaut
define('DB_CHARSET', 'utf8mb4');

// ── URLs & chemins ───────────────────────────────────────────────
$_docRoot  = rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'] ?? ''), '/');
$_projRoot = rtrim(str_replace('\\', '/', realpath(__DIR__ . '/..')), '/');
$_relPath  = ltrim(str_replace($_docRoot, '', $_projRoot), '/');
define('BASE_URL',   'http://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . ($_relPath ? '/' . $_relPath : ''));

// Site principal (famako1/)
if (!defined('UPLOAD_DIR')) {
    define('UPLOAD_DIR', __DIR__ . '/../assets/uploads/');
}
define('MAX_FILE_SIZE',     5368709120);   // 5 Go
define('MAX_PHOTO_SIZE',    15728640);     // 15 Mo

// Bibliothèque numérique (famako1/bibliotheque/)
define('BIB_UPLOAD_PATH',   __DIR__ . '/../bibliotheque/assets/uploads/');
define('BIB_MAX_UPLOAD',    100 * 1024 * 1024);   // 100 Mo
define('BIB_ALLOWED_EXT',   ['pdf','epub','docx','doc','txt','jpg','jpeg','png','mp4','mp3']);
define('BIB_ITEMS_PER_PAGE', 20);

// ── Application ──────────────────────────────────────────────────
define('APP_NAME',      'FaMaKo');
define('APP_SUBTITLE',  'Faculté Maïngo Ködörö — Sciences de l\'Éducation');
define('SECRET_KEY',    'faculte-maingo-kodoro-2026-secret-key');

// ── Connexion PDO (singleton, partagée) ─────────────────────────
function getPDO(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            // En production : logger l'erreur, ne pas l'afficher
            http_response_code(500);
            die(json_encode(['error' => 'Connexion base de données impossible.']));
        }
    }
    return $pdo;
}

// Alias utilisé par la bibliothèque numérique
function getDB(): PDO { return getPDO(); }

// ── Session (démarrée une seule fois) ───────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

// ── Helpers rapides ─────────────────────────────────────────────
function sanitize(string $s): string {
    return htmlspecialchars(trim($s), ENT_QUOTES, 'UTF-8');
}
function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// ── Classes Énumérations (bibliothèque numérique) ────────────────
class UserRole {
    const ADMIN      = 'admin';
    const BIBLIO     = 'bibliothecaire';
    const ENSEIGNANT = 'enseignant';
    const ETUDIANT   = 'etudiant';

    static function badge(string $r): string {
        return match($r) {
            'admin'          => 'danger',
            'bibliothecaire' => 'info',
            'enseignant'     => 'success',
            default          => 'secondary'
        };
    }
    static function label(string $r): string {
        return match($r) {
            'admin'          => 'Administrateur',
            'bibliothecaire' => 'Bibliothécaire',
            'enseignant'     => 'Enseignant',
            'etudiant'       => 'Étudiant',
            default          => ucfirst($r)
        };
    }
    static function all(): array {
        return ['admin', 'bibliothecaire', 'enseignant', 'etudiant'];
    }
}

class DocType {
    static function icon(string $t): string {
        return match($t) {
            'livre'   => 'fa-book',
            'these'   => 'fa-graduation-cap',
            'memoire' => 'fa-file-alt',
            'article' => 'fa-newspaper',
            'cours'   => 'fa-chalkboard-teacher',
            'video'   => 'fa-video',
            'audio'   => 'fa-headphones',
            'archive' => 'fa-archive',
            default   => 'fa-file'
        };
    }
    static function label(string $t): string {
        return match($t) {
            'livre'   => 'Livre',
            'these'   => 'Thèse',
            'memoire' => 'Mémoire',
            'article' => 'Article',
            'cours'   => 'Cours',
            'video'   => 'Vidéo',
            'audio'   => 'Audio',
            'archive' => 'Archive',
            default   => ucfirst($t)
        };
    }
    static function all(): array {
        return ['livre', 'these', 'memoire', 'article', 'cours', 'video', 'audio', 'archive'];
    }
}

class DocStatus {
    const PENDING   = 'en_attente';
    const PUBLISHED = 'publie';
    const ARCHIVED  = 'archive';
    const DRAFT     = 'brouillon';

    static function badge(string $s): string {
        return match($s) {
            'en_attente' => 'warning',
            'publie'     => 'success',
            'archive'    => 'secondary',
            'brouillon'  => 'info',
            default      => 'secondary'
        };
    }
    static function label(string $s): string {
        return match($s) {
            'en_attente' => 'En attente',
            'publie'     => 'Publié',
            'archive'    => 'Archivé',
            'brouillon'  => 'Brouillon',
            default      => ucfirst($s)
        };
    }
}
